package com.example.ucbrowser

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.FrameLayout

/** A frosted liquid-glass panel: blurred wallpaper + tint + shine + bright rim. */
class GlassView(ctx: Context) : FrameLayout(ctx) {
    var fixedRadius = -1f
    var circle = false
    var accentRim = false
    var topOnly = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val dst = Rect()
    private var ox = 0f
    private var oy = 0f

    init { setWillNotDraw(false) }

    private fun offsetIn(root: View) {
        var x = 0f; var y = 0f; var v: View = this
        while (true) {
            x += v.left; y += v.top
            val p = v.parent as? View ?: break
            if (p === root) break
            x -= p.scrollX; y -= p.scrollY
            v = p
        }
        ox = x; oy = y
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val rr = when {
            circle -> minOf(w, h) / 2
            fixedRadius >= 0f -> fixedRadius.dp
            else -> Glass.rad.dp
        }.coerceAtMost(minOf(w, h) / 2)
        rect.set(0f, 0f, w, h)
        path.reset()
        if (topOnly) path.addRoundRect(rect, floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f), Path.Direction.CW)
        else path.addRoundRect(rect, rr, rr, Path.Direction.CW)

        c.save(); c.clipPath(path)
        val wp = Glass.wallpaper
        val bm = wp?.blurred
        if (wp != null && bm != null) {
            offsetIn(wp.parent as View)
            c.save(); c.translate(-ox, -oy)
            dst.set(0, 0, wp.width, wp.height)
            c.drawBitmap(bm, null, dst, bmpPaint)
            c.restore()
        }
        val t = Glass.tint
        fill.shader = LinearGradient(0f, 0f, w, h, intArrayOf(white(t * 1.4f), white(t * .35f), white(t * .85f)),
            floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(rect, fill)
        val sc = Glass.scrim
        if (sc > 0f) {
            fill.shader = null
            fill.color = android.graphics.Color.argb((sc * 255).toInt(), 6, 12, 38)
            c.drawRect(rect, fill)
        }
        fill.shader = RadialGradient(.18f * w, 0f, maxOf(w * .9f, h * .8f),
            intArrayOf(white(Glass.hi * .43f), 0), floatArrayOf(0f, .55f), Shader.TileMode.CLAMP)
        c.drawRect(rect, fill)
        fill.shader = null
        c.restore()

        rim.shader = null; rim.strokeWidth = 2.dp.toFloat(); rim.color = white(Glass.hi * .55f)
        c.drawPath(path, rim)
        rim.shader = LinearGradient(0f, 0f, 0f, h * .5f, white(Glass.hi), 0, Shader.TileMode.CLAMP)
        rim.strokeWidth = 3.dp.toFloat()
        c.drawPath(path, rim)
        rim.shader = null
        if (accentRim) { rim.color = Glass.acc; rim.strokeWidth = 3.dp.toFloat(); c.drawPath(path, rim) }
    }
}
