package com.example.ucbrowser

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator

/** iOS-style liquid glass slider: the thumb stretches while you drag it. */
class GlassSlider(
    ctx: Context, private val min: Float, private val max: Float, var value: Float,
    private val onChange: (Float) -> Unit
) : View(ctx) {
    private var stretch = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val thumbW get() = 38.dp.toFloat()
    private val thumbH get() = 24.dp.toFloat()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val cx = thumbW / 2 + frac * (w - thumbW)
        val th = 8.dp.toFloat()
        p.shader = null; p.color = white(.2f)
        r.set(0f, h / 2 - th / 2, w, h / 2 + th / 2); c.drawRoundRect(r, th / 2, th / 2, p)
        p.color = Glass.acc
        r.set(0f, h / 2 - th / 2, cx, h / 2 + th / 2); c.drawRoundRect(r, th / 2, th / 2, p)
        val tw = thumbW * (1f + .45f * stretch); val tH = thumbH * (1f + .25f * stretch)
        r.set(cx - tw / 2, h / 2 - tH / 2, cx + tw / 2, h / 2 + tH / 2)
        p.color = 0x55000000; c.drawRoundRect(RectF(r.left, r.top + 2.dp, r.right, r.bottom + 2.dp), tH / 2, tH / 2, p)
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, white(.97f), hex("#DDE5FF"), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, tH / 2, tH / 2, p); p.shader = null
    }

    private fun setFromX(x: Float) {
        val frac = ((x - thumbW / 2) / (width - thumbW)).coerceIn(0f, 1f)
        value = min + frac * (max - min)
        onChange(value); invalidate()
    }

    private fun anim(to: Float) {
        ValueAnimator.ofFloat(stretch, to).apply {
            duration = 350; interpolator = OvershootInterpolator(2.5f)
            addUpdateListener { stretch = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent.requestDisallowInterceptTouchEvent(true); anim(1f); setFromX(e.x) }
            MotionEvent.ACTION_MOVE -> setFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anim(0f)
        }
        return true
    }
}
