package com.example.ucbrowser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/** Draws the wallpaper and keeps a blurred copy that glass panels sample from. */
class WallpaperView(ctx: Context) : View(ctx) {
    var blurred: Bitmap? = null
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh); rebuild()
    }

    override fun onDraw(c: Canvas) = render(c, width.toFloat(), height.toFloat())

    fun rebuild() {
        if (width < 8 || height < 8) return
        val sw = (width / 6).coerceAtLeast(8)
        val sh = (height / 6).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(sw / width.toFloat(), sh / height.toFloat())
        render(cv, width.toFloat(), height.toFloat())
        blur(bmp, (Glass.blur.dp / 6f / 1.8f).toInt())
        blurred = bmp
        invalidate()
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, a: Float) {
        val base = color and 0x00FFFFFF
        paint.shader = RadialGradient(cx, cy, r, ((a * 255).toInt() shl 24) or base, base, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint); paint.shader = null
    }

    private fun poly(c: Canvas, color: String, s: Float, oy: Float, vararg pts: Float) {
        path.reset(); path.moveTo(pts[0] * s, oy + pts[1] * s)
        var i = 2
        while (i < pts.size) { path.lineTo(pts[i] * s, oy + pts[i + 1] * s); i += 2 }
        path.close(); paint.color = hex(color); c.drawPath(path, paint)
    }

    private fun render(c: Canvas, w: Float, h: Float) {
        paint.shader = null
        when (Glass.wall) {
            0 -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h,
                    intArrayOf(hex("#2A56C6"), hex("#6D8FE0"), hex("#FFB27A"), hex("#FF8A3D"), hex("#1B2F6E"), hex("#0B1740")),
                    floatArrayOf(0f, .28f, .46f, .52f, .53f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, paint); paint.shader = null
                val s = w / 330f; val oy = h * .30f
                poly(c, "#26396E", s, oy, 0f,160f, 0f,110f, 50f,70f, 90f,100f, 150f,30f, 210f,95f, 260f,60f, 330f,110f, 330f,160f)
                poly(c, "#E9EEFC", s, oy, 150f,30f, 175f,62f, 150f,55f, 128f,66f)
                poly(c, "#14224F", s, oy, 0f,160f, 0f,130f, 70f,105f, 140f,135f, 220f,100f, 330f,135f, 330f,160f)
                blob(c, w * .1f, h * .8f, w * .7f, hex("#FF7A18"), .40f)
                blob(c, w * .95f, h * .1f, w * .8f, hex("#2B4BFF"), .45f)
            }
            1 -> {
                paint.color = hex("#071A2E"); c.drawRect(0f, 0f, w, h, paint)
                blob(c, w * .3f, h * .2f, w * .9f, hex("#22D3A0"), .75f)
                blob(c, w * .8f, h * .6f, w * 1.0f, hex("#8B5CF6"), .8f)
                blob(c, w * .2f, h * .85f, w * .7f, hex("#2B4BFF"), .5f)
            }
            else -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(hex("#050816"), hex("#10204A"), hex("#1B2F6E")),
                    floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, paint); paint.shader = null
                blob(c, w * .85f, h * .15f, w * .7f, hex("#6D5CF6"), .5f)
                blob(c, w * .15f, h * .9f, w * .8f, hex("#FF7A18"), .35f)
            }
        }
    }

    private fun blur(bmp: Bitmap, r: Int) {
        if (r < 1) return
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) { box(px, w, h, r, true); box(px, w, h, r, false) }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun box(px: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val n = if (horiz) w else h
        val lines = if (horiz) h else w
        val out = IntArray(n)
        val d = 2 * r + 1
        for (l in 0 until lines) {
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val k = i.coerceIn(0, n - 1)
                val p = px[if (horiz) l * w + k else k * w + l]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (i in 0 until n) {
                out[i] = (0xFF shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val a = i + r + 1; val b = i - r
                val pa = px[if (horiz) l * w + minOf(a, n - 1) else minOf(a, n - 1) * w + l]
                val pb = px[if (horiz) l * w + maxOf(b, 0) else maxOf(b, 0) * w + l]
                sr += ((pa shr 16) and 255) - ((pb shr 16) and 255)
                sg += ((pa shr 8) and 255) - ((pb shr 8) and 255)
                sb += (pa and 255) - (pb and 255)
            }
            for (i in 0 until n) px[if (horiz) l * w + i else i * w + l] = out[i]
        }
    }
}
