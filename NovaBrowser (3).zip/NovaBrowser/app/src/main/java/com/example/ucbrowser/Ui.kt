package com.example.ucbrowser

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation

const val MATCH = -1
const val WRAP = -2

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun txt(c: Context, s: String, sp: Float = 14f, bold: Boolean = false, color: Int = Color.WHITE) = TextView(c).apply {
    text = s; textSize = sp; setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
    if (Glass.auto) setShadowLayer(8f, 0f, 2f, 0x99000A28.toInt())
}

fun chip(c: Context, s: String, on: Boolean, click: () -> Unit) = txt(c, s, 12f).apply {
    setPadding(12.dp, 7.dp, 12.dp, 7.dp)
    background = GradientDrawable().apply {
        cornerRadius = 16.dp.toFloat(); setColor(if (on) Glass.acc else 0x24FFFFFF); setStroke(1.dp, 0x38FFFFFF)
    }
    setOnClickListener { click() }
    jelly()
}

fun circleLetter(c: Context, letter: String, color: Int, size: Int) = TextView(c).apply {
    text = letter; setTextColor(Color.WHITE); textSize = size * 0.38f; typeface = Typeface.DEFAULT_BOLD
    gravity = android.view.Gravity.CENTER
    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
}

fun iconView(c: Context, res: Int) = ImageView(c).apply { setImageResource(res) }

/** Jelly: squash under the finger, then wobble back on release. */
@SuppressLint("ClickableViewAccessibility")
fun View.jelly() {
    setOnTouchListener { v, e ->
        val j = Glass.jelly
        if (j > 0f) when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                @Suppress("UNCHECKED_CAST")
                (v.getTag(R.id.jelly_tag) as? List<SpringAnimation>)?.forEach { if (it.isRunning) it.cancel() }
                v.pivotX = e.x; v.pivotY = e.y
                v.animate().cancel()
                v.animate().scaleX(1f - 0.16f * j).scaleY(1f - 0.10f * j).setDuration(120).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().cancel()
                val sx = SpringAnimation(v, DynamicAnimation.SCALE_X, 1f).apply { spring.stiffness = 380f; spring.dampingRatio = 0.24f }
                val sy = SpringAnimation(v, DynamicAnimation.SCALE_Y, 1f).apply { spring.stiffness = 300f; spring.dampingRatio = 0.22f }
                v.setTag(R.id.jelly_tag, listOf(sx, sy))
                sx.start(); sy.start()
            }
        }
        false
    }
}
