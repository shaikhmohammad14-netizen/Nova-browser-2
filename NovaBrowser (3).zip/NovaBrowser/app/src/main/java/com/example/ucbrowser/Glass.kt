package com.example.ucbrowser

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** All user-customisable glass / layout settings, saved between launches. */
object Glass {
    const val DEFAULT_ACCENT = 0xFF3B6DFF.toInt()
    var blur = 16f
    var tint = 0.2f
    var hi = 0.7f
    var rad = 22f
    var jelly = 1f
    var acc = DEFAULT_ACCENT
    var abarTop = true
    var dockFloat = true
    var wall = 0
    var auto = true
    var hz = 2
    var ver = 0
    var wallpaper: WallpaperView? = null
    private lateinit var p: SharedPreferences

    val scrim: Float get() = if (auto) maxOf(0f, 0.36f * (1f - tint / 0.5f)) else 0f

    fun init(c: Context) {
        p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)
        blur = p.getFloat("g_blur", 16f); tint = p.getFloat("g_tint", 0.2f); hi = p.getFloat("g_hi", 0.7f)
        rad = p.getFloat("g_rad", 22f); jelly = p.getFloat("g_jelly", 1f); acc = p.getInt("g_acc", DEFAULT_ACCENT)
        abarTop = p.getBoolean("g_abar", true); dockFloat = p.getBoolean("g_dock", true)
        wall = p.getInt("g_wall", 0); auto = p.getBoolean("g_auto", true); hz = p.getInt("g_hz", 2)
    }

    fun save() {
        p.edit().putFloat("g_blur", blur).putFloat("g_tint", tint).putFloat("g_hi", hi).putFloat("g_rad", rad)
            .putFloat("g_jelly", jelly).putInt("g_acc", acc).putBoolean("g_abar", abarTop)
            .putBoolean("g_dock", dockFloat).putInt("g_wall", wall).putBoolean("g_auto", auto).putInt("g_hz", hz).apply()
    }

    fun reset() {
        blur = 16f; tint = 0.2f; hi = 0.7f; rad = 22f; jelly = 1f; acc = DEFAULT_ACCENT
        abarTop = true; dockFloat = true; wall = 0; auto = true
    }
}

fun hex(s: String): Int = Color.parseColor(s)
fun white(a: Float): Int = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), 255, 255, 255)
