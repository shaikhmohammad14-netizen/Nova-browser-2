# HO Browser (liquid glass edition)
Firefox engine (GeckoView) browser with a customisable liquid-glass UI.

Features: glass splash + home with HO logo, speed dial, Discover card, stacked tabs, downloads manager,
settings, and a Customize screen (glass blur / opacity / shine / roundness / jelly sliders, address bar top or
bottom, floating or docked nav, 3 wallpapers, 6 accent colors, "keep text readable" switch).
Jelly spring animation on every touch, refresh-rate control (up to the phone's max, e.g. 120 Hz).

## Build the APK on GitHub (no PC tools needed)
1. Create a new GitHub repo and upload ALL files from this folder (keep the hidden `.github` folder).
2. Open the **Actions** tab -> **Build APK** (it starts by itself after upload; or press "Run workflow").
3. When it turns green open the run -> **Artifacts** -> download `NovaBrowser-debug-apk` -> unzip -> install.

Uninstall any older version first (same package name, different signing key).
Engine version: `geckoVersion` in `app/build.gradle.kts`.
